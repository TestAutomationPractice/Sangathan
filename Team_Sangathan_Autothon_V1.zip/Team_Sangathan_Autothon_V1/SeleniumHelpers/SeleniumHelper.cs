﻿using CommonUtilities.Models;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeleniumHelpers
{

    public static class SeleniumHelper
    {
        public static By ControlBy(FindByOption fbOption, string controlAttributeValue)
        {
            By by;
            switch (fbOption)
            {

                case FindByOption.Id:
                    {
                        by = By.Id(controlAttributeValue);
                        break;
                    }
                case FindByOption.ClassName:
                    {
                        by = By.ClassName(controlAttributeValue);
                        break;
                    }
                case FindByOption.CssSelector:
                    {
                        by = By.CssSelector(controlAttributeValue);
                        break;
                    }
                case FindByOption.Name:
                    {
                        by = By.Name(controlAttributeValue);
                        break;
                    }
                case FindByOption.XPath:
                    {
                        by = By.XPath(controlAttributeValue);
                        break;
                    }
                case FindByOption.LinkText:
                    {
                        by = By.LinkText(controlAttributeValue);
                        break;
                    }
                case FindByOption.PartialLinkText:
                    {
                        by = By.PartialLinkText(controlAttributeValue);
                        break;
                    }
                case FindByOption.TagName:
                    {
                        by = By.TagName(controlAttributeValue);
                        break;
                    }
                default:
                    {
                        by = By.Id(controlAttributeValue);
                        break;
                    }
            }

            return by;
        }
        public static IWebElement FindElement(this IWebDriver driver, By by, int timeoutInSeconds)
        {
            if (timeoutInSeconds > 0)
            {
                var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeoutInSeconds));
                return wait.Until(drv => drv.FindElement(by));
            }
            return driver.FindElement(by);
        }

        public static bool SetText(this IWebDriver driver, FindByOption fOptions, string controlId, string inputText, int timeoutInSeconds)
        {
            try
            {
                By by = ControlBy(fOptions, controlId);
                if (timeoutInSeconds > 0)
                {
                    var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeoutInSeconds));
                    IWebElement control = wait.Until(drv => drv.FindElement(by));
                    control.SendKeys(inputText);
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }

        }
        public static bool Click(this IWebDriver driver, FindByOption fOptions, string controlId, int timeoutInSeconds)
        {
            try
            {
                By by = ControlBy(fOptions, controlId);
                if (timeoutInSeconds > 0)
                {
                    var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeoutInSeconds));
                    IWebElement control = wait.Until(drv => drv.FindElement(by));
                    control.Click();
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }

        }

        public static bool RadioButtonSelection(this IWebDriver driver, FindByOption fOptions, string controlId, int timeoutInSeconds)
        {
            try
            {
                By by = ControlBy(fOptions, controlId);
                if (timeoutInSeconds > 0)
                {
                    var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeoutInSeconds));
                    IWebElement control = wait.Until(drv => drv.FindElement(by));
                    control.Click();
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }

        }

        /// <summary>
        /// Select type drop downs
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="by"></param>
        /// <param name="selectByText"></param>
        /// <param name="timeoutInSeconds"></param>
        /// <returns></returns>
        public static bool SelectByText(this IWebDriver driver, FindByOption fOptions, string controlId, string selectByText, int timeoutInSeconds)
        {
            try
            {
                By by = ControlBy(fOptions, controlId);
                if (timeoutInSeconds > 0)
                {
                    SelectElement oSelect = new SelectElement(driver.FindElement(by));
                    oSelect.SelectByText(selectByText);
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }

        }

        public static bool SelectByValue(this IWebDriver driver, FindByOption fOptions, string controlId, string value, int timeoutInSeconds)
        {
            try
            {
                By by = ControlBy(fOptions, controlId);
                if (timeoutInSeconds > 0)
                {
                    SelectElement oSelect = new SelectElement(driver.FindElement(By.Id("yy_date_8")));
                    oSelect.SelectByValue(value);
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }

        }

        public static bool SelectByIndex(this IWebDriver driver, FindByOption fOptions, string controlId, int index, int timeoutInSeconds)
        {
            try
            {
                By by = ControlBy(fOptions, controlId);
                if (timeoutInSeconds > 0)
                {
                    SelectElement oSelect = new SelectElement(driver.FindElement(by));
                    oSelect.SelectByIndex(index);
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }

        }

        public static bool DragDropAction(this IWebDriver driver, FindByOption fOptionSource, string sourceControlId, FindByOption fOptionDestination, string destinationControlId, int timeoutInSeconds)
        {
            try
            {
                By bySource = ControlBy(fOptionSource, sourceControlId);
                By byDestination = ControlBy(fOptionDestination, destinationControlId);


                if (timeoutInSeconds > 0)
                {
                    var waitForSource = new WebDriverWait(driver, TimeSpan.FromSeconds(timeoutInSeconds));
                    IWebElement controlSource = waitForSource.Until(drv => drv.FindElement(bySource));

                    var waitForDestination = new WebDriverWait(driver, TimeSpan.FromSeconds(timeoutInSeconds));
                    IWebElement controlDestination = waitForDestination.Until(drv => drv.FindElement(byDestination));

                    ////Using Action class for drag and drop.		
                    //Actions act = new Actions(driver);

                    ////Dragged and dropped.		
                    //act.DragAndDrop(controlSource, controlDestination).Build().Perform();

                    Actions action = new Actions(driver);
                    IAction dragdrop = action.ClickAndHold(controlSource).MoveToElement(controlDestination).Release(controlDestination).Build();
                    dragdrop.Perform();

                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }

        }

        public static bool JavascriptAction(this IWebDriver driver, string scriptText, bool returnsValue, ref object returnValue)
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            if (!returnsValue)
            {
                js.ExecuteScript(scriptText);
            }
            else
            {
                returnValue = (bool)js.ExecuteScript(scriptText);
            }

            return true;
        }

        public static string GetControlText(this IWebDriver driver, FindByOption fOptions, string controlId, int timeoutInSeconds)
        {
            string controlText = string.Empty;

            try
            {
                By by = ControlBy(fOptions, controlId);
                if (timeoutInSeconds > 0)
                {
                    var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeoutInSeconds));
                    IWebElement control = wait.Until(drv => drv.FindElement(by));
                    controlText = control.Text;
                }

            }
            catch (Exception ex)
            {
                controlText = "";
            }

            return controlText;
        }

        public static bool MouseHover(this IWebDriver driver, FindByOption fOptions, string controlId, int timeoutInSeconds)
        {
            try
            {
                By by = ControlBy(fOptions, controlId);
                if (timeoutInSeconds > 0)
                {
                    Actions action = new Actions(driver);
                    var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeoutInSeconds));
                    IWebElement control = wait.Until(drv => drv.FindElement(by));
                    action.MoveToElement(control).Perform();
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public static bool SwitchToIFrame(this IWebDriver driver,string frameId)
        {
            try
            {
                driver.SwitchTo().Frame(frameId);
                return true;
            }
            catch (Exception ex)
            {

                return false;
            }
        }
    }


}
