﻿using CommonUtilities.Models;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using SeleniumHelpers;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TestCaseInputManager;
using TestCaseInputManager.Model;

namespace RegressionSuite
{
    [TestFixture]
    public class MainTestClass
    {
        IWebDriver driver;
        InputFromExcel testCaseInputManager = new InputFromExcel();

        [SetUp]
        public void StartBrowser()
        {

            string module = ConfigurationManager.AppSettings["ModuleToBeTested"].ToString();
            if (module.ToLower().Equals("web"))
            {
                string runningDirectory = AppDomain.CurrentDomain.BaseDirectory;
                string chromeDriverPath = Path.Combine(runningDirectory, "ChromeDriver");
                driver = new ChromeDriver(chromeDriverPath);

                string url = string.Empty;

                //URL of the application
                url = ConfigurationManager.AppSettings["ApplicationURL"].ToString();

                driver.Url = url;
                driver.Manage().Window.Maximize();
            }
            else
            {
                //API Testing
            }
           
        }

        [Test]
        public void AddMovie()
        {
            try
            {
                List<TestCaseModel> lstTestCaseData = new List<TestCaseModel>();
                lstTestCaseData = testCaseInputManager.GetTestcaseInputsFromExcel(@"TestCaseFiles\TC1_AddMovie.xlsx");

                bool flag = false;
                foreach (var step in lstTestCaseData)
                {
                    flag = PerformOperations(flag, step);
                }

                string currentURL = driver.Url;
            

            }
            catch (Exception ex)
            {
                throw;
            }


        }

        private bool PerformOperations(bool flag, TestCaseModel step)
        {
            switch (step.OperationToBePerformed)
            {
                case OperationType.Click:
                    {
                        flag = SeleniumHelper.Click(driver, step.FindControlBy, step.ControlIdentificationValue, step.WaitFor);
                        break;
                    }
                case OperationType.SetText:
                    {
                        flag = SeleniumHelper.SetText(driver, step.FindControlBy, step.ControlIdentificationValue, step.ControlValue, step.WaitFor); break;
                    }
                case OperationType.RadioButtonSelection:
                    {
                        flag = SeleniumHelper.RadioButtonSelection(driver, step.FindControlBy, step.ControlIdentificationValue, step.WaitFor);
                        break;
                    }
                case OperationType.SelectByText:
                    break;
                case OperationType.SelectById:
                    break;
                case OperationType.SelectByValue:
                    break;
                case OperationType.DragDropAction:
                    break;
                case OperationType.Wait:
                    {
                        Thread.Sleep(TimeSpan.FromSeconds(Convert.ToInt32(step.ControlValue)));
                        break;
                    }
                case OperationType.MouseHover:
                    {
                        flag = SeleniumHelper.MouseHover(driver, step.FindControlBy, step.ControlIdentificationValue, step.WaitFor);
                        break;
                    }
                case OperationType.None:
                    break;
                case OperationType.SwitchToIFrame:
                    {
                        flag = SeleniumHelper.SwitchToIFrame(driver, step.ControlIdentificationValue);
                        break;
                    }
                case OperationType.Validation:

                    break;
                default:
                    break;
            }

            return flag;
        }

      
        [TearDown]
        public void CloseBrowser()
        {
            driver.Close();
        }

    }
}
