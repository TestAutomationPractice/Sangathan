﻿using CommonUtilities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestCaseInputManager.Model
{
    /// <summary>
    /// This class defines the data structure to store the test case data
    /// </summary>
    public class TestCaseModel
    {
        public string TestCaseNumber { get; set; }
        public string TestCaseDescription { get; set; }
        public string ModuleName { get; set; }
        public int StepNumber { get; set; }
        public string ControlLogicalName { get; set; }
        public FindByOption FindControlBy { get; set; }
        public string ControlIdentificationValue { get; set; }
        public OperationType OperationToBePerformed { get; set; }
        public string ControlValue { get; set; }
        public int WaitFor { get; set; }
        public string URL { get; set; }
    }

    /// <summary>
    /// Operation type to be added.
    /// </summary>
    public enum OperationType
    {
        Click,SetText,RadioButtonSelection, SelectByText, SelectById, SelectByValue, DragDropAction,Wait,MouseHover,SwitchToIFrame, Validation,None
    }
}
