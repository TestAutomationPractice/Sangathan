﻿using CommonUtilities.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using TestCaseInputManager.Model;
using Excel= Microsoft.Office.Interop.Excel;

namespace TestCaseInputManager
{
    public class InputFromExcel
    {
        
        public List<TestCaseModel> GetTestcaseInputsFromExcel(string path)
        {
            List<TestCaseModel> dataset = new List<TestCaseModel>();
            try
            {

                string absolutePath = Path.Combine(System.AppContext.BaseDirectory, path);
                //Create COM Objects. Create a COM object for everything that is referenced
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(absolutePath);
                Excel._Worksheet xlWorksheet = xlWorkbook.Sheets[1];
                Excel.Range xlRange = xlWorksheet.UsedRange;

                Dictionary<string, int> columnMapping = new Dictionary<string, int>();

                //iterate over the rows and columns and print to the console as it appears in the file
                //excel is not zero based!!
                for (int rowIndex = 1; rowIndex <= xlRange.Rows.Count; rowIndex++)
                {
                    TestCaseModel testCaseRecord = new TestCaseModel();

                    for (int columnIndex = 1; columnIndex <= xlRange.Columns.Count; columnIndex++)
                    {
                        if (rowIndex == 1)
                        {
                            columnMapping.Add(xlRange.Cells[rowIndex, columnIndex].Value2.ToString(), columnIndex);
                        }
                        else
                        {
                            //write the value to the console
                            if (xlRange.Cells[rowIndex, columnIndex] != null && xlRange.Cells[rowIndex, columnIndex].Value2 != null)
                            {
                                
                                //TestCaseNumber 
                                if (xlRange.Cells[rowIndex, columnMapping["TestCaseNumber"]].Value2!=null)
                                {
                                    testCaseRecord.TestCaseNumber = Convert.ToString(xlRange.Cells[rowIndex, columnMapping["TestCaseNumber"]].Value2);
                                }
                                else
                                {
                                    testCaseRecord.TestCaseNumber = string.Empty;
                                }

                                //TestCaseDescription
                                if (xlRange.Cells[rowIndex, columnMapping["TestCaseDescription"]].Value2 != null)
                                {
                                    testCaseRecord.TestCaseDescription = Convert.ToString(xlRange.Cells[rowIndex, columnMapping["TestCaseDescription"]].Value2);
                                }
                                else
                                {
                                    testCaseRecord.TestCaseDescription = string.Empty;
                                }

                                //ModuleName
                                if (xlRange.Cells[rowIndex, columnMapping["ModuleName"]].Value2 != null)
                                {
                                    testCaseRecord.ModuleName = Convert.ToString(xlRange.Cells[rowIndex, columnMapping["ModuleName"]].Value2);
                                }
                                else
                                {
                                    testCaseRecord.ModuleName = string.Empty;
                                }

                                //StepNumber
                                if (xlRange.Cells[rowIndex, columnMapping["StepNumber"]].Value2 != null)
                                {
                                    testCaseRecord.StepNumber = Convert.ToInt32(xlRange.Cells[rowIndex, columnMapping["StepNumber"]].Value2.ToString());
                                }
                                else
                                {
                                    testCaseRecord.StepNumber = 0;
                                }

                                //ControlLogicalName
                                if (xlRange.Cells[rowIndex, columnMapping["ControlLogicalName"]].Value2 != null)
                                {
                                    testCaseRecord.ControlLogicalName = Convert.ToString(xlRange.Cells[rowIndex, columnMapping["ControlLogicalName"]].Value2);
                                }
                                else
                                {
                                    testCaseRecord.ControlLogicalName = string.Empty;
                                }

                                //FindControlBy
                                if (xlRange.Cells[rowIndex, columnMapping["FindControlBy"]].Value2 != null)
                                {
                                    //Try parsing the Enum value
                                    Enum.TryParse(xlRange.Cells[rowIndex, columnMapping["FindControlBy"]].Value2.ToString(), out FindByOption findControlBy);
                                    testCaseRecord.FindControlBy = findControlBy;
                                }
                                else
                                {
                                    testCaseRecord.FindControlBy = FindByOption.None;
                                }

                                //ControlIdentificationValue
                                if (xlRange.Cells[rowIndex, columnMapping["ControlIdentificationValue"]].Value2 != null)
                                {
                                    testCaseRecord.ControlIdentificationValue = Convert.ToString(xlRange.Cells[rowIndex, columnMapping["ControlIdentificationValue"]].Value2);
                                }
                                else
                                {
                                    testCaseRecord.ControlIdentificationValue = string.Empty;
                                }

                                //OperationType
                                if (xlRange.Cells[rowIndex, columnMapping["OperationType"]].Value2 != null)
                                {
                                    //Try parsing the Enum value
                                    Enum.TryParse(xlRange.Cells[rowIndex, columnMapping["OperationType"]].Value2.ToString(), out OperationType opType);
                                    testCaseRecord.OperationToBePerformed = opType;
                                }
                                else
                                {
                                    testCaseRecord.OperationToBePerformed = OperationType.None;
                                }

                                //ControlValue
                                if (xlRange.Cells[rowIndex, columnMapping["ControlValue"]].Value2!=null)
                                {
                                    testCaseRecord.ControlValue = Convert.ToString(xlRange.Cells[rowIndex, columnMapping["ControlValue"]].Value2);
                                }
                                else
                                {
                                    testCaseRecord.ControlValue = string.Empty;
                                }

                                //WaitFor
                                if (xlRange.Cells[rowIndex, columnMapping["WaitFor"]].Value2!=null)
                                {
                                    testCaseRecord.WaitFor = Convert.ToInt32(xlRange.Cells[rowIndex, columnMapping["WaitFor"]].Value2.ToString());
                                }
                                else
                                {
                                    testCaseRecord.WaitFor = 0;
                                }

                                //URL
                                if (xlRange.Cells[rowIndex, columnMapping["URL"]].Value2!=null)
                                {
                                    testCaseRecord.URL = Convert.ToString(xlRange.Cells[rowIndex, columnMapping["URL"]].Value2);
                                }
                                else
                                {
                                    testCaseRecord.URL = string.Empty;
                                }
                            }
                            
                        }
                    }
                    if (rowIndex!=1)
                    {
                        dataset.Add(testCaseRecord);
                    }
                }

                CleanUp(xlApp, xlWorkbook, xlWorksheet, xlRange);
            }
            catch (Exception ex)
            {

                throw;
            }

            return dataset;
        }

        private static void CleanUp(Excel.Application xlApp, Excel.Workbook xlWorkbook, Excel._Worksheet xlWorksheet, Excel.Range xlRange)
        {
            //cleanup
            GC.Collect();
            GC.WaitForPendingFinalizers();

            //rule of thumb for releasing com objects:
            //  never use two dots, all COM objects must be referenced and released individually
            //  ex: [somthing].[something].[something] is bad

            //release com objects to fully kill excel process from running in the background
            Marshal.ReleaseComObject(xlRange);
            Marshal.ReleaseComObject(xlWorksheet);

            //close and release
            xlWorkbook.Close();
            Marshal.ReleaseComObject(xlWorkbook);

            //quit and release
            xlApp.Quit();
            Marshal.ReleaseComObject(xlApp);
        }
    }
}
