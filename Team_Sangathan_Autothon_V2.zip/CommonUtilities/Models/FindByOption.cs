﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonUtilities.Models
{
    public enum FindByOption
    {
        Id
        , ClassName
        , CssSelector
        , Name
        , XPath
        , LinkText
        , PartialLinkText
        , TagName
        ,None
    }
}
