﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestAPICall
{
    public class ApplicationAPI
    {
        public void CallGetMovies(string path, string resource, string mType, string headerString, string parameterString, string urlString)
        {
            Method methodType = Method.GET;
            switch (mType)
            {
                case "GET": { methodType = Method.GET; break; }
                case "PUT": { methodType = Method.PUT; break; }
                default:
                    break;
            }
            //string path = @"http://autothon-nagarro-backend-e05.azurewebsites.net/";
            RestClient client = new RestClient(path);
            // RestRequest request = new RestRequest("movies", Method.GET);
            RestRequest request = new RestRequest(resource, methodType);

            var headerdict = StringToDictionary(headerString);
            AddHeader(request, headerdict);

            var parameterDict = StringToDictionary(parameterString);
            AddParameter(request, parameterDict);

            var urlDict = StringToDictionary(urlString);
            AddUrlStatement(request, urlDict);

            IRestResponse<List<Movie>> response = client.Execute<List<Movie>>(request);
        }

        public void Logout(string path, string resource, Method methodType, string headerString, string parameterString, string urlString)
        {
            
            RestClient client = new RestClient(path);
            RestRequest request = new RestRequest(resource, methodType);

           var headerdict=  StringToDictionary( headerString);
            AddHeader(request, headerdict);

            var parameterDict = StringToDictionary(parameterString);
            AddParameter(request, parameterDict);

            var urlDict = StringToDictionary(urlString);
            AddUrlStatement(request, urlDict);

            IRestResponse<bool> response = client.Execute<bool>(request);
        }

        public static void CancelMovieById(string path, string resource, Method methodType, string headerString, string parameterString, string urlString)
        {
            
            RestClient client = new RestClient(path);
            RestRequest request = new RestRequest(resource, methodType);

            var headerdict = StringToDictionary(headerString);
            AddHeader(request, headerdict);

            var parameterDict = StringToDictionary(parameterString);
            AddParameter(request, parameterDict);

            var urlDict = StringToDictionary(urlString);
            AddUrlStatement(request, urlDict);
            try
            {

                IRestResponse<bool> response = client.Execute<bool>(request);
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
        }


        public static void Login(string path, string resource, Method methodType, string headerString, string parameterString, string urlString)
        {

            RestClient client = new RestClient(path);
            RestRequest request = new RestRequest(resource, methodType);

            var headerdict = StringToDictionary(headerString);
            AddHeader(request, headerdict);

            var parameterDict = StringToDictionary(parameterString);
            AddParameter(request, parameterDict);

            var urlDict = StringToDictionary(urlString);
            AddUrlStatement(request, urlDict);

            try
            {

                IRestResponse<User> response = client.Execute<User>(request);
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
        }


        public static Dictionary<string, string> StringToDictionary(string headerString)
        {
            return headerString.Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(part => part.Split('='))
                    .ToDictionary(split => split[0], split => split[1]);

        }

        public static void AddHeader(RestRequest request, Dictionary<string, string> dictionaryData)
        {
            foreach (var item in dictionaryData)
            {
                request.AddHeader(item.Key, item.Value);

            }
        }

        public static void AddParameter(RestRequest request, Dictionary<string, string> dictionaryData)
        {
            foreach (var item in dictionaryData)
            {
                request.AddParameter(item.Key, item.Value);
            }
        }

        public static void AddUrlStatement(RestRequest request, Dictionary<string, string> dictionaryData)
        {
            foreach (var item in dictionaryData)
            {
                request.AddUrlSegment(item.Key, item.Value);
            }
        }
    }
}

