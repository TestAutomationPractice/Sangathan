﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestAPICall
{
    public class Review
    {
        public int id { get; set; }
        public string from { get; set; }
        public string posted { get; set; }
        public string rating { get; set; }
        public string text { get; set; }
    }
}
